package model;
import java.util.Arrays;
import java.util.Comparator;

class Point1{ int x; int y;}
public class ArraySortLocation {
    Point1[] arr;
   
 
    ArraySortLocation(int NumOfInput){
        arr=new Point1[NumOfInput];    //定义对象数组arr，并分配存储的空间
        for(int i=0;i<NumOfInput;i++)
            arr[i]=new Point1();
        }
   
    public static int[] SortWithIndex(int [] Input) {
        
        ArraySortLocation sort=new ArraySortLocation(Input.length);
       
        int[] Location = new int[Input.length]; 
       
        for(int i=0;i<Input.length;i++)
        {  	sort.arr[i].x=Input[i];
            sort.arr[i].y=i;
        }	
       
        Arrays.sort(sort.arr, new MyComprator());    //使用指定的排序器，进行排序
        
        for(int i=0;i<Input.length;i++)    //输出排序结果
            {
//        	System.out.println(sort.arr[i].x+","+sort.arr[i].y);
            Location[i]=sort.arr[i].y;
            }
        return Location;
    }
}



//比较器，x坐标从小到大排序；x相同时，按照y从小到大排序
class MyComprator implements Comparator {
    public int compare(Object arg0, Object arg1) {
        Point1 t1=(Point1)arg0;
        Point1 t2=(Point1)arg1;
        if(t1.x != t2.x)
            return t1.x>t2.x? 1:-1;
        else
            return t1.y>t2.y? 1:-1;
    }
}