package model;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;
import java.util.Arrays;
import java.util.Random;

//import recommender.common.CommonRecomm_NoBias;

//涓嶅甫姝ｅ垯鍖栫殑BRISMF
public class MF_New_initMF extends CommonRecomm_NEW_MF {

	public MF_New_initMF(int errorType) throws NumberFormatException, IOException {
		super();
		this.err_type = errorType;// 缁�
		// TODO Auto-generated constructor stub
	}

	static int m = 1;

	public void train() throws IOException {
		double sumRating = 0; /// 鎬诲垎
		double sum = 0; /// 璁℃暟鍣�
		double Globalaverage = 0; // 鍏ㄥ眬骞冲潎
		double[] Bi = new double[item_MaxID + 1]; /// 瀵归」鐩甶鎵撳垎鐨勫垎鏁板拰
		double[] Bu = new double[user_MaxID + 1]; /// 鐢ㄦ埛u鎵撳垎鐨勫垎鏁板拰

		double[] tempPu = new double[featureDimension];
		double[] tempDeltaPu = new double[featureDimension];
		double[] tempQi = new double[featureDimension];
		double[] tempDeltaQi = new double[featureDimension];

		int[] Ri = new int[item_MaxID + 1]; /// 瀵归」鐩甶鎵撳垎鐨勭敤鎴锋暟
		int[] Ru = new int[user_MaxID + 1]; /// 鐢ㄦ埛u鎵撳垎鐨勯」鐩暟
		double[] bi = new double[item_MaxID + 1]; /// 瀵归」鐩甶鎵撳垎鐨勫垎鏁板拰
		double[] bu = new double[user_MaxID + 1]; /// 鐢ㄦ埛u鎵撳垎鐨勫垎鏁板拰
		double[] sumC = new double[user_MaxID + 1];
		double Riave = 0;
		double Ruave = 0;

		////////////// 璁＄畻鍏ㄥ眬骞冲潎鍒�//////////////////
		for (RTuple tempRating : trainData) {
			sumRating += tempRating.dRating;
			sum++;
			Ri[tempRating.iItemID]++;
			bi[tempRating.iItemID] += tempRating.dRating;
			Ru[tempRating.iUserID]++;
			bu[tempRating.iUserID] += tempRating.dRating;
		}

		for (int i = 1; i <= item_MaxID; i++) {
			Riave += Ri[i];
		}
		Riave = Riave / item_MaxID / 20;

		for (int j = 1; j <= user_MaxID; j++) {
			Ruave += Ru[j];
		}
		Ruave = Ruave / user_MaxID / 20;

		/////////////// 浼拌鐢ㄦ埛鍜岄」鐩殑鍋忓樊////////////////////////
		switch (m) {
		case 1: {
			Globalaverage = 0;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		case 2: {
			Globalaverage = sumRating / sum;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 3: {
			Globalaverage = 0;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 4: {
			Globalaverage = sumRating / sum;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 5: {
			Globalaverage = sumRating / sum;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		case 6: {
			Globalaverage = 0;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 7: {
			Globalaverage = 0;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		case 8: {
			Globalaverage = sumRating / sum;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		}
		///////// 杩唬璁粌杩囩▼寮�濮嬶紝杩唬璁粌娆℃暟涓簍rainingRound锛屽垵濮嬪�间负1000////////
		for (int round = 1; round <= trainingRound; round++) {
			for (RTuple tempRating : trainData) /// 璇诲彇璁粌鏁版嵁杩涜瀛︿範
			{
				double rPrediction = tempRating.dRating - Globalaverage - Bi[tempRating.iItemID]
						- Bu[tempRating.iUserID];

				double ratingHat = this.getLocPrediction(tempRating.iUserID, tempRating.iItemID);
				double err = rPrediction - ratingHat;

				vectorMutiply(P[tempRating.iUserID], (1 - eta * lambda), tempPu);
				vectorMutiply(P[tempRating.iUserID], err * eta, tempDeltaPu);

				vectorMutiply(Q[tempRating.iItemID], (1 - eta * lambda), tempQi);
				vectorMutiply(Q[tempRating.iItemID], err * eta, tempDeltaQi);

				vectorAdd(tempPu, tempDeltaQi, P[tempRating.iUserID]);
				vectorAdd(tempQi, tempDeltaPu, Q[tempRating.iItemID]);

			}

			double curErr;
			double curErr1;
			double[][] curRank_metric = get_Rank_metric(10);

			double hit = curRank_metric[0][10];
			double ndcg = curRank_metric[1][10];
			double mrr = curRank_metric[2][10];

			curErr = this.testCurrentRMSEu(Bi, Bu, Globalaverage);

			if (min_Error > curErr) {
				min_Error = curErr;
				this.min_Round = round;
				
				File file1 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\rating\\MAE\\lambda="
						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
				File file2 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\rating\\MAE\\lambda="
						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
																			// Q鏄疘tem鐗瑰緛鐭╅樀
				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
				for (int i = 1; i <= user_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out1.write(P[i][j] + " ");
					}
					out1.write("\r\n");
				}
				for (int i = 1; i <= item_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out2.write(Q[i][j] + " ");
					}
					out2.write("\r\n");
				}
				out1.close();
				out2.close();

			} else if ((round - this.min_Round) >= delayCount) {
				break;
			}

			curErr1 = this.testCurrentMAEu(Bi, Bu, Globalaverage);
			if (min_Error1 > curErr1) {
				min_Error1 = curErr1;
				this.min_Round = round;

				File file1 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\rating\\RMSE\\lambda="
						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
				File file2 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\rating\\RMSE\\lambda="
						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
																			// Q鏄疘tem鐗瑰緛鐭╅樀
				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
				for (int i = 1; i <= user_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out1.write(P[i][j] + " ");
					}
					out1.write("\r\n");
				}
				for (int i = 1; i <= item_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out2.write(Q[i][j] + " ");
					}
					out2.write("\r\n");
				}
				out1.close();
				out2.close();

			} else if ((round - this.min_Round) >= delayCount) {
				break;
			}
//
//			if (max_ndcg < ndcg) {
//				max_ndcg = ndcg;
//				this.min_Round = round;
//
//				File file1 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\ranking\\NDCG\\lambda="
//						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
//																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
//				File file2 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\ranking\\NDCG\\lambda="
//						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
//																			// Q鏄疘tem鐗瑰緛鐭╅樀
//				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
//				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
//				for (int i = 1; i <= user_MaxID; i++) {
//					for (int j = 0; j < featureDimension; j++) {
//						out1.write(P[i][j] + " ");
//					}
//					out1.write("\r\n");
//				}
//				for (int i = 1; i <= item_MaxID; i++) {
//					for (int j = 0; j < featureDimension; j++) {
//						out2.write(Q[i][j] + " ");
//					}
//					out2.write("\r\n");
//				}
//				out1.close();
//				out2.close();
//
//			} else if ((round - this.min_Round) >= delayCount) {
//				break;
//			}
//			if (max_hit < hit) {
//				max_hit = hit;
//				this.min_Round = round;
//
//				File file1 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\ranking\\HIT\\lambda="
//						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
//																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
//				File file2 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\ranking\\HIT\\lambda="
//						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
//																			// Q鏄疘tem鐗瑰緛鐭╅樀
//				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
//				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
//				for (int i = 1; i <= user_MaxID; i++) {
//					for (int j = 0; j < featureDimension; j++) {
//						out1.write(P[i][j] + " ");
//					}
//					out1.write("\r\n");
//				}
//				for (int i = 1; i <= item_MaxID; i++) {
//					for (int j = 0; j < featureDimension; j++) {
//						out2.write(Q[i][j] + " ");
//					}
//					out2.write("\r\n");
//				}
//				out1.close();
//				out2.close();
//
//			} else if ((round - this.min_Round) >= delayCount) {
//				break;
//			}
//			if (max_mrr < mrr) {
//				max_mrr = mrr;
//				this.min_Round = round;
//
//				File file1 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\ranking\\MRR\\lambda="
//						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
//																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
//				File file2 = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\ranking\\MRR\\lambda="
//						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
//																			// Q鏄疘tem鐗瑰緛鐭╅樀
//				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
//				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
//				for (int i = 1; i <= user_MaxID; i++) {
//					for (int j = 0; j < featureDimension; j++) {
//						out1.write(P[i][j] + " ");
//					}
//					out1.write("\r\n");
//				}
//				for (int i = 1; i <= item_MaxID; i++) {
//					for (int j = 0; j < featureDimension; j++) {
//						out2.write(Q[i][j] + " ");
//					}
//					out2.write("\r\n");
//				}
//				out1.close();
//				out2.close();
//
//			} else if ((round - this.min_Round) >= delayCount) {
//				break;
//			}

			System.out.println("round:" + round + "\t" + "RMSE:" + "\t" + curErr + "\t" + "MAE:" + "\t" + curErr1);
//			System.out.println("round:" + round + "\t" + "NDCG:" + "\t" + ndcg + "\t" + "Hit:" + "\t" + hit + "\t"
//					+ "MRR:" + "\t" + mrr);

		}
	}

	public static boolean addFile(String string, String path) {
		// 文件的续写
		FileWriter fw = null;
		try {
			fw = new FileWriter(path, true);
			// 写入换行
			fw.write("\r\n");
			fw.write(string);
			fw.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	public double[][] get_Rank_metric(int K) {
		double[] ndcg = new double[K + 1];
		double[] hit = new double[K + 1];
		double[] mrr = new double[K + 1];
		double[][] result = new double[3][K + 1];

		int test_num = 0;
		int userID = 1;
		int[] user_Positive_item = new int[item_MaxID + 1];
		int[] user_Negative_item = new int[item_MaxID + 1];
		int user_Positive_item_num = 0;
		int user_Negative_item_num = 0;

		for (RTuple tempTestRating : testData) {
			if (tempTestRating.iUserID == userID) {
				if (tempTestRating.dRating > 3) {
					user_Positive_item_num = user_Positive_item_num + 1;
					user_Positive_item[user_Positive_item_num] = tempTestRating.iItemID;
				} else {
					user_Negative_item_num = user_Negative_item_num + 1;
					user_Negative_item[user_Negative_item_num] = tempTestRating.iItemID;
				}
			} else {
				int tempuserID = userID;
				// 用户user的item已经全部存储完毕，开始计算该用户的NDCG
				if ((user_Positive_item_num != 0) && (user_Negative_item_num != 0)) {
					double[][] ndcg_user = new double[K + 1][user_Positive_item_num + 1];
					double[][] hit_user = new double[K + 1][user_Positive_item_num + 1];
					double[][] mrr_user = new double[K + 1][user_Positive_item_num + 1];
					int rand_Positive_idx = 0;
					test_num++;

					for (int i = 1; i <= user_Positive_item_num; i++) {
						int Positive_item;
						double[] tiny_test = new double[101 + 1];
						Positive_item = user_Positive_item[i];
						if (user_Negative_item_num >= 100) {
							Random random = new Random();
							rand_Positive_idx = random.nextInt(100 + 1) + 1;
							// 随机选择100个负向商品进行计算
							int[] r = new int[101 + 1];
							for (int idx = 1; idx < r.length;) {
								int temp = random.nextInt(user_Negative_item_num) + 1;
								for (int j : r) {
									if ((j == temp) || (idx == rand_Positive_idx))
										continue;
								}
								r[idx] = temp;
								idx++;
							}
							for (int idx = 1; idx <= 101; idx++) {
								if (idx == rand_Positive_idx) {
									tiny_test[idx] = this.getLocPrediction(tempuserID, Positive_item);
								} else {
									int Negative_item = user_Negative_item[r[idx]];
									tiny_test[idx] = this.getLocPrediction(tempuserID, Negative_item);
								}
							}

						} else {
							tiny_test = new double[user_Negative_item_num + 1 + 1];
							Random random = new Random();
							rand_Positive_idx = random.nextInt(user_Negative_item_num + 1) + 1;

							int[] r = new int[user_Negative_item_num + 1 + 1];
							for (int idx = 1; idx < r.length;) {
								int temp = random.nextInt(user_Negative_item_num) + 1;
								for (int j : r) {
									if ((j == temp) || (idx == rand_Positive_idx))
										continue;
								}
								r[idx] = temp;
								idx++;
							}

							for (int idx = 1; idx <= user_Negative_item_num + 1; idx++) {
								if (idx == rand_Positive_idx) {
									tiny_test[idx] = this.getLocPrediction(tempuserID, Positive_item);
								} else {
									int Negative_item = user_Negative_item[r[idx]];
									tiny_test[idx] = this.getLocPrediction(tempuserID, Negative_item);
								}
							}
						}
						// 排序得出positive排名
						int[] rank_list = Arraysort(tiny_test);
						int rank_ui = getArrayIndex(rank_list, rand_Positive_idx);
						// System.out.print("rank_ui: " + rank_ui + "\n");
						for (int k = 1; k <= K; k++) {
							if (rank_ui <= k) {
								hit_user[k][i] = 1;
								ndcg_user[k][i] = 1.0 / log2(1 + rank_ui);
								mrr_user[k][i] = 1.0 / rank_ui;
							}
						}
					} // 保存完
					double temp_hit = 0;
					double temp_ndcg = 0;
					double temp_mrr = 0;
					for (int k = 1; k <= K; k++) {
						temp_hit = 0;
						temp_ndcg = 0;
						temp_mrr = 0;
						for (int i = 1; i <= user_Positive_item_num; i++) {
							temp_hit = temp_hit + hit_user[k][i];
							temp_ndcg = temp_ndcg + ndcg_user[k][i];
							temp_mrr = temp_mrr + mrr_user[k][i];
						}
						temp_hit /= user_Positive_item_num;
						temp_ndcg /= user_Positive_item_num;
						temp_mrr /= user_Positive_item_num;
						hit[k] = hit[k] + temp_hit;
						ndcg[k] = ndcg[k] + temp_ndcg;
						mrr[k] = mrr[k] + temp_mrr;
					}
//					System.out.print("hit_mean: " + temp_hit + "\n");
//					System.out.print("ndcg_mean: " + temp_ndcg + "\n");
//					System.out.print("mrr_mean: " + temp_mrr + "\n");
				}
				userID = tempTestRating.iUserID;
				user_Positive_item = new int[item_MaxID + 1];
				user_Negative_item = new int[item_MaxID + 1];
				user_Positive_item_num = 0;
				user_Negative_item_num = 0;

				if (tempTestRating.dRating > 3) {
					user_Positive_item_num = user_Positive_item_num + 1;
					user_Positive_item[user_Positive_item_num] = tempTestRating.iItemID;
				} else {
					user_Negative_item_num = user_Negative_item_num + 1;
					user_Negative_item[user_Negative_item_num] = tempTestRating.iItemID;
				}
			}
		}
		// 最后一个用户user的item已经全部存储完毕，开始计算该用户的NDCG
		// 用户user的item已经全部存储完毕，开始计算该用户的NDCG
		if ((user_Positive_item_num != 0) && (user_Negative_item_num != 0)) {
			double[][] ndcg_user = new double[K + 1][user_Positive_item_num + 1];
			double[][] hit_user = new double[K + 1][user_Positive_item_num + 1];
			double[][] mrr_user = new double[K + 1][user_Positive_item_num + 1];
			int rand_Positive_idx = 0;
			test_num++;

			for (int i = 1; i <= user_Positive_item_num; i++) {
				int Positive_item;
				double[] tiny_test = new double[101 + 1];
				Positive_item = user_Positive_item[i];
				if (user_Negative_item_num >= 100) {
					Random random = new Random();
					rand_Positive_idx = random.nextInt(100 + 1) + 1;
					// 随机选择100个负向商品进行计算
					int[] r = new int[101 + 1];
					for (int idx = 1; idx < r.length;) {
						int temp = random.nextInt(user_Negative_item_num) + 1;
						for (int j : r) {
							if ((j == temp) || (idx == rand_Positive_idx))
								continue;
						}
						r[idx] = temp;
						idx++;
					}
					for (int idx = 1; idx <= 101; idx++) {
						if (idx == rand_Positive_idx) {
							tiny_test[idx] = this.getLocPrediction(userID, Positive_item);
						} else {
							int Negative_item = user_Negative_item[r[idx]];
							tiny_test[idx] = this.getLocPrediction(userID, Negative_item);
						}
					}

				} else {
					tiny_test = new double[user_Negative_item_num + 1 + 1];
					Random random = new Random();
					rand_Positive_idx = random.nextInt(user_Negative_item_num + 1) + 1;

					int[] r = new int[user_Negative_item_num + 1 + 1];
					for (int idx = 1; idx < r.length;) {
						int temp = random.nextInt(user_Negative_item_num) + 1;
						for (int j : r) {
							if ((j == temp) || (idx == rand_Positive_idx))
								continue;
						}
						r[idx] = temp;
						idx++;
					}

					for (int idx = 1; idx <= user_Negative_item_num + 1; idx++) {
						if (idx == rand_Positive_idx) {
							tiny_test[idx] = this.getLocPrediction(userID, Positive_item);
						} else {
							int Negative_item = user_Negative_item[r[idx]];
							tiny_test[idx] = this.getLocPrediction(userID, Negative_item);
						}
					}
				}
				// 排序得出positive排名
				int[] rank_list = Arraysort(tiny_test);
				int rank_ui = getArrayIndex(rank_list, rand_Positive_idx);
				// System.out.print("rank_ui: " + rank_ui + "\n");
				for (int k = 1; k <= K; k++) {
					if (rank_ui <= k) {
						hit_user[k][i] = 1;
						ndcg_user[k][i] = 1.0 / log2(1 + rank_ui);
						mrr_user[k][i] = 1.0 / rank_ui;
					}
				}
			} // 保存完
			double temp_hit = 0;
			double temp_ndcg = 0;
			double temp_mrr = 0;
			for (int k = 1; k <= K; k++) {
				temp_hit = 0;
				temp_ndcg = 0;
				temp_mrr = 0;
				for (int i = 1; i <= user_Positive_item_num; i++) {
					temp_hit = temp_hit + hit_user[k][i];
					temp_ndcg = temp_ndcg + ndcg_user[k][i];
					temp_mrr = temp_mrr + mrr_user[k][i];
				}
				temp_hit /= user_Positive_item_num;
				temp_ndcg /= user_Positive_item_num;
				temp_mrr /= user_Positive_item_num;
				hit[k] = hit[k] + temp_hit;
				ndcg[k] = ndcg[k] + temp_ndcg;
				mrr[k] = mrr[k] + temp_mrr;
			}
//			System.out.print("hit_mean: " + temp_hit + "\n");
//			System.out.print("ndcg_mean: " + temp_ndcg + "\n");
//			System.out.print("mrr_mean: " + temp_mrr + "\n");
		}

		// 计算平均值
		for (int k = 1; k <= K; k++) {
			hit[k] = hit[k] / test_num;
			result[0][k] = hit[k];
			ndcg[k] = ndcg[k] / test_num;
			result[1][k] = ndcg[k];
			mrr[k] = mrr[k] / test_num;
			result[2][k] = mrr[k];
		}
		return result;

	}

	public double log2(double N) {
		return Math.log(N) / Math.log(2);// Math.log的底为e
	}

	public static int[] Arraysort(double[] arr) {
		// double[] arr = {5.5,2,66,3,7,5};[ ,1,2,3,4,5,6]
		double temp;
		int index;
		int k = arr.length; // 0~k
		int[] Index = new int[k];
		for (int i = 1; i <= k - 1; i++) {
			Index[i] = i;
		}

		for (int i = 1; i <= arr.length - 1; i++) {
			for (int j = 1; j <= arr.length - 1 - i; j++) {
				if (arr[j] < arr[j + 1]) {
					temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;

					index = Index[j];
					Index[j] = Index[j + 1];
					Index[j + 1] = index;
				}
			}
		}
		return Index;
	}

	public int getArrayIndex(int[] arr, int value) {

		int k = 0;
		for (int i = 1; i < arr.length; i++) {
			if (arr[i] == value) {
				k = i;
				break;
			}
		}
		return k;
	}

	//////////////////////// 鎵�鏈夌殑璁粌缁撴潫//////////////////////////////////
	public static void main(String[] args) throws NumberFormatException, IOException {
		// CommonRecomm_NEW.initializeRatings("./train_1M.txt", "./test_1M.txt", "::");
		CommonRecomm_NEW_MF.dataset_name = "Epinion";
		String trainpath = "D:\\Lishihui\\BDELFA\\new_data2\\" + dataset_name + "\\train.txt";
		String testpath = "D:\\Lishihui\\BDELFA\\new_data2\\" + dataset_name + "\\test.txt";
		CommonRecomm_NEW_MF.initializeRatings(trainpath, testpath, " ");
		String addpath = "D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\new_data2_result.txt";
		String string;

//		File file = new File("D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + dataset_name + "\\result.txt");
//		FileWriter out = new FileWriter(file);

		for (int s = 4; s <= 4; s++)
			for (int t = 2; t <= 2; t++) {
				double Fx = Math.pow(2, (s));// for adjusting featureDimension
				int Fxx = (int) Fx;// for adjusting featureDimension

				CommonRecomm_NEW_MF.eta = 0.01;// 缁涘绨崗顒�绱℃稉顓犳畱绾敍灞筋劅娑旂娀锟界喓宸�
				// CommonRecomm_NEW.lambda = 0.01 * t;// 缁涘绨崗顒�绱℃稉顓犳畱浣嶉敍灞筋劅娑旂娀锟界喓宸�
				CommonRecomm_NEW_MF.lambda = Math.pow(10, (0 - t));//
				CommonRecomm_NEW_MF.trainingRound = 2000;
				CommonRecomm_NEW_MF.featureDimension = Fxx;// 5*t
				CommonRecomm_NEW_MF.delayCount = 30;// 璺冲嚭寰幆鐨勫欢杩熻凯浠ｈ疆鏁帮紝鍙妭鐪佹椂闂�

				CommonRecomm_NEW_MF.initiStaticArrays();
				CommonRecomm_NEW_MF.initBiasSettings(true, true, 1, 1);
				min_Error = 1e10;
				min_Error1 = 1e10;
				max_ndcg = 0;
				max_mrr = 0;
				max_hit = 0;

				MF_New_initMF mf_New_2 = new MF_New_initMF(1); // 1:RMSE;other:MAE.

				mf_New_2.m = 1;//

				long startTime = System.currentTimeMillis();// 璁℃椂闂寸殑寮�濮�

				mf_New_2.train();

				long endTime = System.currentTimeMillis();// 璁℃椂闂寸殑鎴
				double seconds = (endTime - startTime) / 1000F;

				System.out.println("dataset" + CommonRecomm_NEW_MF.dataset_name + "\t \n");
				
				System.out.println("lambda" + lambda + "\t" + "RMSE:" + min_Error + "\t" + "MAE:" + min_Error1 + "\t"
						+ "mf_New.min_Round:" + mf_New_2.min_Round + "\t" + "NDCG:" + max_ndcg + "\t" + "MRR:" + max_mrr
						+ "\t" + "HIT:" + max_hit + "\t \n");
				string = ("featureDimension: " + featureDimension + "\t" + "lambda" + lambda + "\t" + "RMSE:"
						+ min_Error + "\t" + "MAE:" + min_Error1 + "\t" + "mf_New.min_Round:" + mf_New_2.min_Round
						+ "\t" + "NDCG:" + max_ndcg + "\t" + "MRR:" + max_mrr + "\t" + "HIT:" + max_hit + "\t \n");
				addFile(string, addpath);
			}
	}
}
