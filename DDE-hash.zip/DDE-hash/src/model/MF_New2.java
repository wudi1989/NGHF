package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.io.FileWriter;
import java.io.File;

import java.util.Arrays;//sorting function class
import java.util.Collections;
import java.util.Random;

/////Following is used for Java calling MATLAB
import com.mathworks.toolbox.javabuilder.MWArray;
import com.mathworks.toolbox.javabuilder.MWClassID;
import com.mathworks.toolbox.javabuilder.MWComplexity;
import com.mathworks.toolbox.javabuilder.MWNumericArray;
import LMF_PP.Class1; //Class1 is a class,which is the Function written by myself. 

public class MF_New2 extends CommonRecomm_NEW {

	public MF_New2(int errorType) throws NumberFormatException, IOException {
		super();
		this.err_type = errorType;
		// TODO Auto-generated constructor stub
	}

	static int m = 1;// type for bias
	int typeOfLoss = 1;
	int G = 20; // Max value for times of evolution
	int tpyeOfRegularization = 1;// type of regularization

	public void train() throws IOException {
		double sumRating = 0; /// 鎬诲垎
		double sum = 0; /// 璁℃暟鍣�
		double Globalaverage = 0; // 鍏ㄥ眬骞冲潎
		double[] Bi = new double[item_MaxID + 1]; /// 瀵归」鐩甶鎵撳垎鐨勫垎鏁板拰
		double[] Bu = new double[user_MaxID + 1]; /// 鐢ㄦ埛u鎵撳垎鐨勫垎鏁板拰

		double[] P_fitness = new double[user_MaxID + 1];
		double[] Q_fitness = new double[item_MaxID + 1];
		double p_paraments = 1.0 / G;

		int[] Ri = new int[item_MaxID + 1]; /// 瀵归」鐩甶鎵撳垎鐨勭敤鎴锋暟
		int[] Ru = new int[user_MaxID + 1]; /// 鐢ㄦ埛u鎵撳垎鐨勯」鐩暟
		double[] bi = new double[item_MaxID + 1]; /// 瀵归」鐩甶鎵撳垎鐨勫垎鏁板拰
		double[] bu = new double[user_MaxID + 1]; /// 鐢ㄦ埛u鎵撳垎鐨勫垎鏁板拰
		double[] sumC = new double[user_MaxID + 1];
		double Riave = 0;
		double Ruave = 0;
		int LengthTrainData = 0;

		for (RTuple tempRating : trainData) {
			sumRating += tempRating.dRating;
			sum++;
			Ri[tempRating.iItemID]++;
			bi[tempRating.iItemID] += tempRating.dRating;
			Ru[tempRating.iUserID]++;
			bu[tempRating.iUserID] += tempRating.dRating;
			LengthTrainData = LengthTrainData + 1;
		}

		for (int i = 1; i <= item_MaxID; i++) {
			Riave += Ri[i];
		}
		Riave = Riave / item_MaxID / 20;

		for (int j = 1; j <= user_MaxID; j++) {
			Ruave += Ru[j];
		}
		Ruave = Ruave / user_MaxID / 20;
		switch (m) {
		case 1: {
			Globalaverage = 0;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		case 2: {
			Globalaverage = sumRating / sum;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 3: {
			Globalaverage = 0;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 4: {
			Globalaverage = sumRating / sum;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 5: {
			Globalaverage = sumRating / sum;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		case 6: {
			Globalaverage = 0;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (RTuple tempRating : trainData) {
				sumC[tempRating.iUserID] += Bi[tempRating.iItemID];
			}
			getItemBias(Globalaverage, bu, Ru, Ruave, sumC, Bu);
		}
			break;
		case 7: {
			Globalaverage = 0;
			getUseBias(Globalaverage, bi, Ri, Riave, Bi);
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		case 8: {
			Globalaverage = sumRating / sum;
			for (int i = 1; i < item_MaxID; i++) {
				Bi[i] = 0;
			}
			for (int j = 1; j < user_MaxID; j++) {
				Bu[j] = 0;
			}
		}
			break;
		}
		
///////////////////////初始化完成
		
		
		if (flag_init) {
			String P_file = "D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + CommonRecomm_NEW.dataset_name + "\\rating\\MAE\\lambda=0.01"
					+ "_P_r=" + featureDimension + ".txt";
			initP_withMF(P_file, " ", P);
			String Q_file = "D:\\Lishihui\\BDELFA\\MatrixFactorization\\" + CommonRecomm_NEW.dataset_name + "\\rating\\MAE\\lambda=0.01"
					+ "_Q_r=" + featureDimension + ".txt";
			initQ_withMF(Q_file, " ", Q);
		}

///////////////////列表法:将输入数据按User排序转为按Item排序输入/////////////////////////   
		int[] userIDorder1 = new int[LengthTrainData + 1];
		int[] itemIDorder1 = new int[LengthTrainData + 1];
		double[] RatingValueUser = new double[LengthTrainData + 1];
		LengthTrainData = 0;
		for (RTuple tempRating : trainData) {
			LengthTrainData += 1;
			userIDorder1[LengthTrainData] = tempRating.iUserID;
			itemIDorder1[LengthTrainData] = tempRating.iItemID;
			RatingValueUser[LengthTrainData] = tempRating.dRating;
		}

		int[] Location = new int[LengthTrainData + 1];
		Location = new ArraySortLocation(1).SortWithIndex(itemIDorder1); // ArraySortLocation:sort itemIDorder1 return
																			// location order

		int[] userIDorder = new int[LengthTrainData + 1];
		int[] itemIDorder = new int[LengthTrainData + 1];
		double[] RatingValue = new double[LengthTrainData + 1];

		for (int i = 1; i <= LengthTrainData; i++) {
			userIDorder[i] = userIDorder1[Location[i]];
			itemIDorder[i] = itemIDorder1[Location[i]];
			RatingValue[i] = RatingValueUser[Location[i]];
		}

		for (int round = 1; round <= trainingRound; round++) {
			int row = 1;
			int Num = 0;
			double Sum_err_g = 0;
			int[] iItemID_tem = new int[item_MaxID + 1];
			int TrainNum = 0;
			double[] Rating_row_tem = new double[item_MaxID + 1];

			
			// 输入一条评分数据，判断是不是用户row，如果是开始计算损失 
			for (RTuple tempRating : trainData) {
				TrainNum = TrainNum + 1;
				if (tempRating.iUserID == row) {
					iItemID_tem[Num + 1] = tempRating.iItemID;
					Rating_row_tem[Num + 1] = tempRating.dRating;
					Num = Num + 1;

					double ratingHat = tempRating.dRating - Globalaverage - Bi[tempRating.iItemID]
							- Bu[tempRating.iUserID];
					double rPrediction = this.getLocPrediction(tempRating.iUserID, tempRating.iItemID);
					double Frobenius_err = (ratingHat - rPrediction);

					double Frobenius_square_P;
					double Frobenius_square_Q;

					// 约束
					double sum_P = 0;
					double sum_Q = 0;
					vectorSum(P[tempRating.iUserID], sum_P);
					vectorSum(Q[tempRating.iItemID], sum_Q);
					Frobenius_square_P = sum_P * sum_P;
					Frobenius_square_Q = sum_Q * sum_Q;

					if (typeOfLoss == 1) {
						double err_g = Math.abs(Frobenius_err) + lambda * (Frobenius_square_P + Frobenius_square_Q);
						Sum_err_g = Sum_err_g + err_g;
					} else {
						double err_g = Math.pow(Frobenius_err, 2) + lambda * (Frobenius_square_P + Frobenius_square_Q);
						Sum_err_g = Sum_err_g + err_g;
					}

					// P
				} else {
					p_paraments = 1.0 / G;
					for (int g = 1; g <= G; g++) {
						///// P: mutation and crossover operation///////
						p_paraments = p_paraments * g;
						double[] P_trial = new double[featureDimension];
						/// generate the trial
						
						if ( mutate_type == 0 ) {
							int rand = (int) Math.round(Math.random() * (6 - 1)) + 1;
							mutate_type = rand;
						}
						if (mutate_type == 1) {
							P_trial = GenerateTrailVector_Rand1(tempRating.iUserID - 1, user_MaxID, P);
						} else if (mutate_type == 2) {
							P_trial = GenerateTrailVector_Rand2(tempRating.iUserID - 1, user_MaxID, P);
						} else if (mutate_type == 3) {
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_Best1(tempRating.iUserID - 1, user_MaxID, P, best_userID);
						} else if (mutate_type == 4) {
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_Best2(tempRating.iUserID - 1, user_MaxID, P, best_userID);
						} else if (mutate_type == 5) {
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_RandToBest1(tempRating.iUserID - 1, user_MaxID, P, best_userID);
						} else if (mutate_type == 6){
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_RandToBest2(tempRating.iUserID - 1, user_MaxID, P, best_userID);
						}
						
						if (mutate_type == 7)
						{
							P_trial = GenerateTrailVector_Rand1(tempRating.iUserID - 1, user_MaxID, P);
							if (p_paraments > Math.random()) {
								int best_userID = getMaxIndex(P_fitness);
								P_trial = GenerateTrailVector_Best2(tempRating.iUserID - 1, user_MaxID, P, best_userID);
							}
						}
						

						///// P: sum the predict err of row///////
						double Sum_err_g_row = 0;
						for (int i = 1; i <= Num; i++) {
							double ratingHat = Rating_row_tem[i] - Globalaverage - Bi[iItemID_tem[i]]
									- Bu[tempRating.iUserID - 1];
							
							double err_temp = ratingHat - 5.0 / (1.0 / (1 - (vectorSum_NOT_AND(P_trial, Q[iItemID_tem[i]])/(featureDimension))));
							

							double Frobenius_square_P_trial;
							double Frobenius_square_Q_trial;

//							// 约束
							double sum_P = 0;
							double sum_Q = 0;
							vectorSum(P_trial, sum_P);
							vectorSum(Q[iItemID_tem[i]], sum_Q);
							Frobenius_square_P_trial = sum_P * sum_P;
							Frobenius_square_Q_trial = sum_Q * sum_Q;

							if (typeOfLoss == 1) {
								double err_g_row = Math.abs(err_temp)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row = Sum_err_g_row + err_g_row;
							} else {
								double err_g_row = Math.pow(err_temp, 2)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row = Sum_err_g_row + err_g_row;
							}

						}

						///// P: sum the predict err of row///////
						///// P: selection///////
						if (Sum_err_g_row < Sum_err_g) {
//							double[][] temp_P = P;
//							temp_P[tempRating.iUserID - 1] = P_trial;
//							if (Punish_fitness(temp_P, Q, featureDimension) <= Punish_fitness(P, Q, featureDimension)) {
//								P[tempRating.iUserID - 1] = P_trial;
//								Sum_err_g = Sum_err_g_row;
//								P_fitness[tempRating.iUserID - 1] = Sum_err_g;
//							}
							
//							Sum_err_g_row = Sum_err_g_row
//									+ lambda * 0.001 * Punish_fitness(P, Q, featureDimension) / user_MaxID;
							
							P[tempRating.iUserID - 1] = P_trial;
							Sum_err_g = Sum_err_g_row;
							P_fitness[tempRating.iUserID - 1] = Sum_err_g;
							//System.out.println("P更新: " + (tempRating.iUserID - 1) + "\n");
						} ///// P: selection///////

					} //// over differential evolution DE:for (int g = 1; g <= G; g++)

					row = row + 1;// update row
					Num = 1;// update Num
					iItemID_tem[Num] = tempRating.iItemID;// the first point for row+1
					Rating_row_tem[Num] = tempRating.dRating;
					double ratingHat = tempRating.dRating - Globalaverage - Bi[tempRating.iItemID]
							- Bu[tempRating.iUserID];
					double rPrediction = this.getLocPrediction(tempRating.iUserID, tempRating.iItemID);
					double Frobenius_err = (ratingHat - rPrediction);

					double Frobenius_square_P;
					double Frobenius_square_Q;

					// 约束
					double sum_P = 0;
					double sum_Q = 0;
					vectorSum(P[tempRating.iUserID], sum_P);
					vectorSum(Q[tempRating.iItemID], sum_Q);
					Frobenius_square_P = sum_P * sum_P;
					Frobenius_square_Q = sum_Q * sum_Q;

					if (typeOfLoss == 1) {
						Sum_err_g = Math.abs(Frobenius_err) + lambda * (Frobenius_square_P + Frobenius_square_Q);
					} else {
						Sum_err_g = Math.pow(Frobenius_err, 2) + lambda * (Frobenius_square_P + Frobenius_square_Q);
					}

				} /// else

				/// for the last row
				if (TrainNum == LengthTrainData) {
					p_paraments = 1.0 / G;
					for (int g = 1; g <= G; g++) {
						///// P: mutation and crossover operation///////
						p_paraments = p_paraments * g;
						double[] P_trial = new double[featureDimension];
						
//						double rand = Math.random();
//						if (rand < 1/3) {
//							P_trial = GenerateTrailVector_Rand1(tempRating.iUserID, user_MaxID, P);;
//						} else if (1/3 <= rand && rand < 2/3) {
//							int best_userID = getMaxIndex(P_fitness);
//							P_trial = GenerateTrailVector_Best1(tempRating.iUserID, user_MaxID, P, best_userID);
//						} else {
//							int best_userID = getMaxIndex(P_fitness);
//							P_trial = GenerateTrailVector_RandToBest1(tempRating.iUserID, user_MaxID, P, best_userID);
//						}
						
						if ( mutate_type == 0 ) {
							int rand = (int) Math.round(Math.random() * (6 - 1)) + 1;
							mutate_type = rand;
						}
						if (mutate_type == 1) {
							P_trial = GenerateTrailVector_Rand1(tempRating.iUserID, user_MaxID, P);
						} else if (mutate_type == 2) {
							P_trial = GenerateTrailVector_Rand2(tempRating.iUserID, user_MaxID, P);
						} else if (mutate_type == 3) {
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_Best1(tempRating.iUserID, user_MaxID, P, best_userID);
						} else if (mutate_type == 4) {
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_Best2(tempRating.iUserID, user_MaxID, P, best_userID);
						} else if (mutate_type == 5) {
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_RandToBest1(tempRating.iUserID, user_MaxID, P, best_userID);
						} else if (mutate_type == 6){
							int best_userID = getMaxIndex(P_fitness);
							P_trial = GenerateTrailVector_RandToBest2(tempRating.iUserID, user_MaxID, P, best_userID);
						}
						
						if (mutate_type == 7)
						{
							P_trial = GenerateTrailVector_Rand1(tempRating.iUserID, user_MaxID, P);
							if (p_paraments > Math.random()) {
								int best_userID = getMaxIndex(P_fitness);
								P_trial = GenerateTrailVector_Best2(tempRating.iUserID, user_MaxID, P, best_userID);
							}
						}

						///// P: sum the predict err of row///////
						double Sum_err_g_row = 0;
						for (int i = 1; i <= Num; i++) {
							double ratingHat = Rating_row_tem[i] - Globalaverage - Bi[iItemID_tem[i]]
									- Bu[tempRating.iUserID];
							
							double err_temp = ratingHat - 5.0 / (1.0 / (1 - (vectorSum_NOT_AND(P_trial, Q[iItemID_tem[i]])/(featureDimension))));

							double Frobenius_square_P_trial;
							double Frobenius_square_Q_trial;

							// 约束
							double sum_P = 0;
							double sum_Q = 0;
							vectorSum(P_trial, sum_P);
							vectorSum(Q[iItemID_tem[i]], sum_Q);
							Frobenius_square_P_trial = sum_P * sum_P;
							Frobenius_square_Q_trial = sum_Q * sum_Q;

							if (typeOfLoss == 1) {
								double err_g_row = Math.abs(err_temp)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row = Sum_err_g_row + err_g_row;
							} else {
								double err_g_row = Math.pow(err_temp, 2)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row = Sum_err_g_row + err_g_row;
							}
						}
						///// P: sum the predict err of row///////

						///// P: selection///////
						if (Sum_err_g_row < Sum_err_g) {
							P[tempRating.iUserID] = P_trial;
							Sum_err_g = Sum_err_g_row;
							P_fitness[tempRating.iUserID] = Sum_err_g;
						} ///// P: selection///////

					} //// over differential evolution DE:for (int g = 1; g <= G; g++)

				} /// if (TrainNum==LengthTrainData)

			} // over for update P: for (RTuple tempRating : trainData)

////////////////////////////////////update Q///////////////////////////////////////////////////////////////////////////////////		

			int row1 = 1;
			int Num1 = 0;
			double Sum_err_g1 = 0;
			int[] UserID_tem = new int[user_MaxID + 1];
			TrainNum = 0;
			double[] Rating_column_tem = new double[user_MaxID + 1];

			for (int i = 1; i <= LengthTrainData; i++) {
				TrainNum = TrainNum + 1;
				if (itemIDorder[i] == row1) {
					UserID_tem[Num1 + 1] = userIDorder[i];
					Rating_column_tem[Num1 + 1] = RatingValue[i];
					Num1 = Num1 + 1;

					double ratingHat = RatingValue[i] - Globalaverage - Bi[itemIDorder[i]] - Bu[userIDorder[i]];
					double rPrediction = this.getLocPrediction(userIDorder[i], itemIDorder[i]);
					//System.out.print("rPrediction: " + rPrediction + "\n");

					double Frobenius_err = (ratingHat - rPrediction);

//					 System.out.println(" " + ratingHat + '-' + rPrediction + '=' + Frobenius_err
//					 + '\n');

					double Frobenius_square_P;
					double Frobenius_square_Q;

					// 约束
					double sum_P = 0;
					double sum_Q = 0;
					vectorSum(P[userIDorder[i]], sum_P);
					vectorSum(Q[itemIDorder[i]], sum_Q);
					Frobenius_square_P = sum_P * sum_P;
					Frobenius_square_Q = sum_Q * sum_Q;

					if (typeOfLoss == 1) {
						double err_g = Math.abs(Frobenius_err) + lambda * (Frobenius_square_P + Frobenius_square_Q);
						Sum_err_g1 += err_g;
					} else {
						double err_g = Math.pow(Frobenius_err, 2) + lambda * (Frobenius_square_P + Frobenius_square_Q);
						Sum_err_g1 += err_g;
					}

				} else {
					p_paraments = 1.0 / G;
					for (int g = 1; g <= G; g++) {
						///// P: mutation and crossover operation///////
						p_paraments = p_paraments * g;
						double[] Q_trial = new double[featureDimension];
						
						if ( mutate_type == 0 ) {
							int rand = (int) Math.round(Math.random() * (6 - 1)) + 1;
							mutate_type = rand;
						}
						if (mutate_type == 1) {
							Q_trial = GenerateTrailVector_Rand1(itemIDorder[i] - 1, item_MaxID, Q);;
						} else if (mutate_type == 2) {
							Q_trial = GenerateTrailVector_Rand2(itemIDorder[i] - 1, item_MaxID, Q);
						} else if (mutate_type == 3) {
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_Best1(itemIDorder[i] - 1, item_MaxID, Q, best_itemID);
						} else if (mutate_type == 4) {
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_Best2(itemIDorder[i] - 1, item_MaxID, Q, best_itemID);
						} else if (mutate_type == 5) {
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_RandToBest1(itemIDorder[i] - 1, item_MaxID, Q, best_itemID);
						} else if (mutate_type == 6){
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_RandToBest2(itemIDorder[i] - 1, item_MaxID, Q, best_itemID);
						}
						
						if (mutate_type == 7)
						{
							Q_trial = GenerateTrailVector_Rand1(itemIDorder[i] - 1, item_MaxID, Q);
							if (p_paraments > Math.random()) {
								int best_itemID = getMaxIndex(Q_fitness);
								Q_trial = GenerateTrailVector_Best2(itemIDorder[i] - 1, item_MaxID, Q, best_itemID);
							}
						}

						///// P: sum the predict err of row///////
						double Sum_err_g_row = 0;
						for (int j = 1; j <= Num1; j++) {
							double ratingHat = Rating_column_tem[j] - Globalaverage - Bi[itemIDorder[i] - 1]
									- Bu[UserID_tem[j]];
							
							double err_temp = ratingHat - 5.0 / (1.0 / (1 - (vectorSum_NOT_AND(P[UserID_tem[j]], Q_trial)/(featureDimension))));
							
							double Frobenius_square_P_trial;
							double Frobenius_square_Q_trial;

							// 约束
							double sum_P = 0;
							double sum_Q = 0;
							vectorSum(P[UserID_tem[j]], sum_P);
							vectorSum(Q_trial, sum_Q);
							Frobenius_square_P_trial = sum_P * sum_P;
							Frobenius_square_Q_trial = sum_Q * sum_Q;

							if (typeOfLoss == 1) {
								double err_g_row = Math.abs(err_temp)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row += err_g_row;
							} else {
								double err_g_row = Math.pow(err_temp, 2)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row += err_g_row;
							}

						}

						///// P: selection///////
						if (Sum_err_g_row < Sum_err_g1) {
							
							Q[itemIDorder[i] - 1] = Q_trial;
							Sum_err_g1 = Sum_err_g_row;
							Q_fitness[itemIDorder[i] - 1] = Sum_err_g1;
						} ///// P: selection///////

					} //// over differential evolution DE:for (int g = 1; g <= G; g++)

					// update information for the first if
					row1 = row1 + 1;// update row
					Num1 = 1;// update Num
					UserID_tem[Num1] = userIDorder[i];// the first point for row+1
					Rating_column_tem[Num1] = RatingValue[i];
					double ratingHat = RatingValue[i] - Globalaverage - Bi[itemIDorder[i]] - Bu[userIDorder[i]];
					double rPrediction = this.getLocPrediction(userIDorder[i], itemIDorder[i]);
					double Frobenius_err = (ratingHat - rPrediction);

					double Frobenius_square_P;
					double Frobenius_square_Q;

					// 约束
					double sum_P = 0;
					double sum_Q = 0;
					vectorSum(P[userIDorder[i]], sum_P);
					vectorSum(Q[itemIDorder[i]], sum_Q);
					Frobenius_square_P = sum_P * sum_P;
					Frobenius_square_Q = sum_Q * sum_Q;

					if (typeOfLoss == 1) {
						Sum_err_g1 = Math.abs(Frobenius_err) + lambda * (Frobenius_square_P + Frobenius_square_Q);
					} else {
						Sum_err_g1 = Math.pow(Frobenius_err, 2) + lambda * (Frobenius_square_P + Frobenius_square_Q);
					}

				} /// else

				/// for the last row
				if (TrainNum == LengthTrainData) {
					p_paraments = 1.0 / G;
					for (int g = 1; g <= G; g++) {
						p_paraments = p_paraments * g;
						///// P: mutation and crossover operation///////
						double[] Q_trial = new double[featureDimension];
						
						if ( mutate_type == 0 ) {
							int rand = (int) Math.round(Math.random() * (6 - 1)) + 1;
							mutate_type = rand;
						}
						
						if (mutate_type == 1) {
							Q_trial = GenerateTrailVector_Rand1(itemIDorder[i], item_MaxID, Q);;
						} else if (mutate_type == 2) {
							Q_trial = GenerateTrailVector_Rand2(itemIDorder[i], item_MaxID, Q);
						} else if (mutate_type == 3) {
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_Best1(itemIDorder[i], item_MaxID, Q, best_itemID);
						} else if (mutate_type == 4) {
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_Best2(itemIDorder[i], item_MaxID, Q, best_itemID);
						} else if (mutate_type == 5) {
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_RandToBest1(itemIDorder[i], item_MaxID, Q, best_itemID);
						} else if (mutate_type == 6){
							int best_itemID = getMaxIndex(Q_fitness);
							Q_trial = GenerateTrailVector_RandToBest2(itemIDorder[i], item_MaxID, Q, best_itemID);
						}
						
						if (mutate_type == 7)
						{
							Q_trial = GenerateTrailVector_Rand1(itemIDorder[i], item_MaxID, Q);
							if (p_paraments > Math.random()) {
								int best_itemID = getMaxIndex(Q_fitness);
								Q_trial = GenerateTrailVector_Best2(itemIDorder[i], item_MaxID, Q, best_itemID);
							}
						}
						
						///// P: sum the predict err of row///////
						double Sum_err_g_row = 0;
						for (int j = 1; j <= Num1; j++) {
							double ratingHat = Rating_column_tem[j] - Globalaverage - Bi[itemIDorder[i]]
									- Bu[UserID_tem[j]];
							
							double err_temp = ratingHat - 5.0 / (1.0 / (1 - (vectorSum_NOT_AND(P[UserID_tem[j]], Q_trial)/(featureDimension))));
							

							double Frobenius_square_P_trial;
							double Frobenius_square_Q_trial;

							// 约束
							double sum_P = 0;
							double sum_Q = 0;
							vectorSum(P[UserID_tem[j]], sum_P);
							vectorSum(Q_trial, sum_Q);
							Frobenius_square_P_trial = sum_P * sum_P;
							Frobenius_square_Q_trial = sum_Q * sum_Q;

							if (typeOfLoss == 1) {
								double err_g_row = Math.abs(err_temp)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row += err_g_row;
							} else {
								double err_g_row = Math.pow(err_temp, 2)
										+ lambda * (Frobenius_square_P_trial + Frobenius_square_Q_trial);
								Sum_err_g_row += err_g_row;
							}
						}

						///// P: sum the predict err of row///////

						///// P: selection///////
						if (Sum_err_g_row < Sum_err_g1) {
							Q[itemIDorder[i]] = Q_trial;
							Sum_err_g1 = Sum_err_g_row;
							Q_fitness[itemIDorder[i]] = Sum_err_g1;
						} ///// P: selection///////
						
						

					} //// over differential evolution DE:for (int g = 1; g <= G; g++)

				} /// if (TrainNum==LengthTrainData)

			} /// over update Q
//	         Q=Q_distribution.clone();

			// ////////testing on test results.
			double curErr_RMSE, curErr_MAE;
			double[][] curRank_metric = get_Rank_metric(10);

			double hit = curRank_metric[0][10];
			double ndcg = curRank_metric[1][10];
			double mrr = curRank_metric[2][10];

			curErr_RMSE = this.testCurrentRMSEu(Bi, Bu, Globalaverage);
			curErr_MAE = this.testCurrentMAEu(Bi, Bu, Globalaverage);// testCheck
			System.out.println("round:" + round + "\t" + "RMSE:" + "\t" + curErr_RMSE + "\t" + "MAE:" + "\t" + curErr_MAE);
			System.out.println("round:" + round + "\t" + "NDCG:" + "\t" + ndcg + "\t" + "Hit:" + "\t" + hit + "\t"
					+ "MRR:" + "\t" + mrr);
			
			String addpath = "D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\lambda="
					+ lambda + "_P_r=" + featureDimension + "_new_data_train_init.txt";
			String string = (round + " " + curErr_RMSE + " " + curErr_MAE + " "+ ndcg + " " + hit + " "
				+ mrr + "\n");
			addFile(string, addpath);
			
			if (min_Error > curErr_RMSE) {
				min_Error = curErr_RMSE;
				this.min_Round = round;

				File file1 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\rating\\RMSE\\lambda="
						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
				File file2 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\rating\\RMSE\\lambda="
						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
																			// Q鏄疘tem鐗瑰緛鐭╅樀
				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
				for (int i = 1; i <= user_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out1.write(P[i][j] + " ");
					}
					out1.write("\r\n");
				}
				for (int i = 1; i <= item_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out2.write(Q[i][j] + " ");
					}
					out2.write("\r\n");
				}
				out1.close();
				out2.close();

			} else if ((round - this.min_Round) >= delayCount) {
				break;
			}

			if (min_Error1 > curErr_MAE) {
				min_Error1 = curErr_MAE;
				this.min_Round = round;

				File file1 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\rating\\MAE\\lambda="
						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
				File file2 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\rating\\MAE\\lambda="
						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
																			// Q鏄疘tem鐗瑰緛鐭╅
				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
				for (int i = 1; i <= user_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out1.write(P[i][j] + " ");
					}
					out1.write("\r\n");
				}
				for (int i = 1; i <= item_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out2.write(Q[i][j] + " ");
					}
					out2.write("\r\n");
				}
				out1.close();
				out2.close();

			} else if ((round - this.min_Round) >= delayCount) {
				break;
			}

			if (max_ndcg < ndcg) {
				max_ndcg = ndcg;
				this.min_Round = round;

				File file1 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\ranking\\NDCG\\lambda="
						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
				File file2 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\ranking\\NDCG\\lambda="
						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
																			// Q鏄疘tem鐗瑰緛鐭╅
				// Q鏄疘tem鐗瑰緛鐭╅樀
				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
				for (int i = 1; i <= user_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out1.write(P[i][j] + " ");
					}
					out1.write("\r\n");
				}
				for (int i = 1; i <= item_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out2.write(Q[i][j] + " ");
					}
					out2.write("\r\n");
				}
				out1.close();
				out2.close();

			} else if ((round - this.min_Round) >= delayCount) {
				break;
			}
			if (max_hit < hit) {
				max_hit = hit;
				this.min_Round = round;

				File file1 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\ranking\\HIT\\lambda="
						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
				File file2 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\ranking\\HIT\\lambda="
						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
																			// Q鏄疘tem鐗瑰緛鐭╅
				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
				for (int i = 1; i <= user_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out1.write(P[i][j] + " ");
					}
					out1.write("\r\n");
				}
				for (int i = 1; i <= item_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out2.write(Q[i][j] + " ");
					}
					out2.write("\r\n");
				}
				out1.close();
				out2.close();

			} else if ((round - this.min_Round) >= delayCount) {
				break;
			}
			if (max_mrr < mrr) {
				max_mrr = mrr;
				this.min_Round = round;

				File file1 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\ranking\\MRR\\lambda="
						+ lambda + "_P_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠�
																			// 锛孭鏄疷ser鐗瑰緛鐭╅樀
				File file2 = new File("D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\ranking\\MRR\\lambda="
						+ lambda + "_Q_r=" + featureDimension + ".txt"); // 瀛樻斁鏁扮粍鏁版嵁鐨勬枃浠讹紝
																			// Q鏄疘tem鐗瑰緛鐭╅
				// Q鏄疘tem鐗瑰緛鐭╅樀
				FileWriter out1 = new FileWriter(file1); // 鏂囦欢鍐欏叆娴�
				FileWriter out2 = new FileWriter(file2); // 鏂囦欢鍐欏叆娴�
				for (int i = 1; i <= user_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out1.write(P[i][j] + " ");
					}
					out1.write("\r\n");
				}
				for (int i = 1; i <= item_MaxID; i++) {
					for (int j = 0; j < featureDimension; j++) {
						out2.write(Q[i][j] + " ");
					}
					out2.write("\r\n");
				}
				out1.close();
				out2.close();

			} else if ((round - this.min_Round) >= delayCount) {
				break;
			}

		} // round 一轮完
	}


	public static double[] GenerateTrailVector_Rand1(int UserID, int MaxID, double[][] P)//// GenerateTrailVector for a row of
																					//// UserID
	{
		double SFGSS = 1;
		double SFHC = 0;
		double Fl = 0.1;
		double Fu = 0.9;
		double tuo1 = 0.1;
		double tuo2 = 0.03;
		double tuo3 = 0.07;
		double CR = 0.75;// 交叉的概率
		double[] temp = new double[featureDimension];
		double[] temp1 = new double[featureDimension];
		double[] P_mutation = new double[featureDimension];
		double[] temp_P_trial = new double[featureDimension];
		double[] P_trial = new double[featureDimension];

		int u1 = UserID;
		int u2 = UserID;
		int u3 = UserID;
		while (u1 == UserID) {
			u1 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u2 == UserID) || (u2 == u1)) {
			u2 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u3 == UserID) || (u3 == u2) || (u3 == u1)) {
			u3 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}

		double rand1 = Math.random();
		double rand2 = Math.random();
		double rand3 = Math.random();
		double F = Math.random();
		double K = Math.random();
		if (rand3 < tuo2) {
			F = SFGSS;
		} else if (tuo2 <= rand3 && rand3 < tuo3) {
			F = SFHC;
		} else if (rand2 < tuo1 && rand3 > tuo3) {
			F = Fl + Fu * rand1;
		}
		// System.out.println("F:" + F);
		
//		vectorxor(P[u2], P[u3], temp);
//		vectorMutiplyXor(temp, F, temp1);
//		vectorxor(P[u1], temp1, P_mutation);
		
		vectorSub(P[u2], P[u3], temp);
		vectorMutiply(temp, F, temp1);
		vectorAdd(P[u1], temp1, P_mutation);
		vectorMeanRound(P_mutation,P_mutation);
		
		double rand0 = Math.random();
		int rand_d = (int) Math.round(Math.random() * (featureDimension - 1)); // random int [0,featureDimension-1]}
		for (int d = 0; d < featureDimension; d++) {
			if ((rand0 < CR) || (d == rand_d)) {
				P_trial[d] = P_mutation[d];
			} else {
				P_trial[d] = P[UserID][d];
			}
		}

//		vectorAdd(P_mutation, P[UserID], temp);
//		vectorMutiply(temp, K, temp1);
//		vectorAdd(P[UserID], temp1, P_trial);
//		vectorMeanRound(P_trial,P_trial);
		
		return P_trial;
	}

	public static double[] GenerateTrailVector_RandToBest2(int UserID, int MaxID, double[][] P, int Best_UserID) {
		double SFGSS = 1;
		double SFHC = 0;
		double Fl = 0.1;
		double Fu = 0.9;
		double tuo1 = 0.1;
		double tuo2 = 0.03;
		double tuo3 = 0.07;
		double CR = 0.75;// 交叉的概率
		double[] temp = new double[featureDimension];
		double[] temp1 = new double[featureDimension];
		double[] temp2 = new double[featureDimension];
		double[] P_mutation = new double[featureDimension];
		double[] P_trial = new double[featureDimension];

		int u1 = UserID;
		int u2 = UserID;
		int u3 = UserID;
		int u4 = UserID;
		while ((u1 == UserID) || (u1 == Best_UserID)) {
			u1 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u2 == UserID) || (u2 == u1) || (u2 == Best_UserID)) {
			u2 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u3 == UserID) || (u3 == u2) || (u3 == u1) || (u3 == Best_UserID)) {
			u3 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u4 == UserID) || (u4 == u3) || (u4 == u2) || (u4 == u1) || (u4 == Best_UserID)) {
			u4 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}

		double rand1 = Math.random();
		double rand2 = Math.random();
		double rand3 = Math.random();
		double F = Math.random();
		double K = Math.random();
		if (rand3 < tuo2) {
			F = SFGSS;
		} else if (tuo2 <= rand3 && rand3 < tuo3) {
			F = SFHC;
		} else if (rand2 < tuo1 && rand3 > tuo3) {
			F = Fl + Fu * rand1;
		}
		
		vectorSub(P[u1], P[u2], temp);
		vectorMutiply(temp, F, temp1);
		vectorSub(P[u3], P[u4], temp);
		vectorMutiply(temp, F, temp2);
		vectorAdd(temp1, temp2, temp2);
		vectorSub(P[Best_UserID], P[UserID], temp1);
		vectorMutiply(temp1, F, temp1);
		vectorAdd(temp1, temp2, temp);
		vectorAdd(P[UserID], temp, P_mutation);	
		vectorMeanRound(P_mutation,P_mutation);
		
		double rand0 = Math.random();
		int rand_d = (int) Math.round(Math.random() * (featureDimension - 1)); // random int [0,featureDimension-1]}
		for (int d = 0; d < featureDimension; d++) {
			if ((rand0 < CR) || (d == rand_d)) {
				P_trial[d] = P_mutation[d];
			} else {
				P_trial[d] = P[UserID][d];
			}
		}
		
//		vectorAdd(P_mutation, P[UserID], temp);
//		vectorMutiply(temp, K, temp1);
//		vectorAdd(P[UserID], temp1, P_trial);
//		vectorMeanRound(P_trial,P_trial);
//		
		return P_trial;
	}
	
	public static double[] GenerateTrailVector_Best1(int UserID, int MaxID, double[][] P, int Best_UserID) {
		double SFGSS = 1;
		double SFHC = 0;
		double Fl = 0.1;
		double Fu = 0.9;
		double tuo1 = 0.1;
		double tuo2 = 0.03;
		double tuo3 = 0.07;
		double CR = 0.75;// 交叉的概率
		double[] temp = new double[featureDimension];
		double[] temp1 = new double[featureDimension];
		double[] temp2 = new double[featureDimension];
		double[] P_mutation = new double[featureDimension];
		double[] temp_P_trial = new double[featureDimension];
		double[] P_trial = new double[featureDimension];

		int u1 = UserID;
		int u2 = UserID;
		int u3 = UserID;
		int u4 = UserID;
		while ((u1 == UserID) || (u1 == Best_UserID)) {
			u1 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u2 == UserID) || (u2 == u1) || (u1 == Best_UserID)) {
			u2 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}

		double rand1 = Math.random();
		double rand2 = Math.random();
		double rand3 = Math.random();
		double F = Math.random();
		double K = Math.random();
		if (rand3 < tuo2) {
			F = SFGSS;
		} else if (tuo2 <= rand3 && rand3 < tuo3) {
			F = SFHC;
		} else if (rand2 < tuo1 && rand3 > tuo3) {
			F = Fl + Fu * rand1;
		}
		
		vectorSub(P[u1], P[u2], temp);
		vectorMutiply(temp, F, temp1);
		vectorAdd(P[Best_UserID], temp1, P_mutation);	
		vectorMeanRound(P_mutation,P_mutation);
		
		double rand0 = Math.random();
		int rand_d = (int) Math.round(Math.random() * (featureDimension - 1)); // random int [0,featureDimension-1]}
		for (int d = 0; d < featureDimension; d++) {
			if ((rand0 < CR) || (d == rand_d)) {
				P_trial[d] = P_mutation[d];
			} else {
				P_trial[d] = P[UserID][d];
			}
		}
		
//		vectorAdd(P_mutation, P[UserID], temp);
//		vectorMutiply(temp, K, temp1);
//		vectorAdd(P[UserID], temp1, P_trial);
//		vectorMeanRound(P_trial,P_trial);
//		
		return P_trial;
	}
	
	
	public static double[] GenerateTrailVector_RandToBest1(int UserID, int MaxID, double[][] P, int Best_UserID) {
		double SFGSS = 1;
		double SFHC = 0;
		double Fl = 0.1;
		double Fu = 0.9;
		double tuo1 = 0.1;
		double tuo2 = 0.03;
		double tuo3 = 0.07;
		double CR = 0.75;// 交叉的概率
		double[] temp = new double[featureDimension];
		double[] temp1 = new double[featureDimension];
		double[] temp2 = new double[featureDimension];
		double[] P_mutation = new double[featureDimension];
		double[] temp_P_trial = new double[featureDimension];
		double[] P_trial = new double[featureDimension];

		int u1 = UserID;
		int u2 = UserID;
		int u3 = UserID;
		int u4 = UserID;
		while ((u1 == UserID) || (u1 == Best_UserID)) {
			u1 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u2 == UserID) || (u2 == u1) || (u1 == Best_UserID)) {
			u2 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}

		double rand1 = Math.random();
		double rand2 = Math.random();
		double rand3 = Math.random();
		double F = Math.random();
		double K = Math.random();
		if (rand3 < tuo2) {
			F = SFGSS;
		} else if (tuo2 <= rand3 && rand3 < tuo3) {
			F = SFHC;
		} else if (rand2 < tuo1 && rand3 > tuo3) {
			F = Fl + Fu * rand1;
		}
		
		vectorSub(P[u1], P[u2], temp);
		vectorMutiply(temp, F, temp1);
		vectorSub(P[Best_UserID], P[UserID], temp);
		vectorMutiply(temp, F, temp2);
		vectorAdd(temp1, temp2, temp);
		vectorAdd(P[UserID], temp, P_mutation);	
		vectorMeanRound(P_mutation,P_mutation);
		
		double rand0 = Math.random();
		int rand_d = (int) Math.round(Math.random() * (featureDimension - 1)); // random int [0,featureDimension-1]}
		for (int d = 0; d < featureDimension; d++) {
			if ((rand0 < CR) || (d == rand_d)) {
				P_trial[d] = P_mutation[d];
			} else {
				P_trial[d] = P[UserID][d];
			}
		}
		
//		vectorAdd(P_mutation, P[UserID], temp);
//		vectorMutiply(temp, K, temp1);
//		vectorAdd(P[UserID], temp1, P_trial);
//		vectorMeanRound(P_trial,P_trial);
//		
		return P_trial;
	}

	public static int[] SortVectorReturnLocation(int[] Input) {

		int[] Sort_Input = new int[Input.length];
		int[] Location = new int[Input.length];
		int[] Input1 = new int[Input.length];

		Sort_Input = Input.clone();// completely Sort_Input=Input;
		Input1 = Input.clone();

		Arrays.sort(Sort_Input);

		for (int i = 1; i <= Input.length - 1; i++)
			for (int j = 1; j <= Input.length - 1; j++) {
				if (Sort_Input[i] == Input[j]) {
					Location[i] = j;
					Input[j] = 0;
					break;
				}
			}
		for (int i = 1; i <= Input.length - 1; i++) {

			Input[i] = Input1[i];
		}

		return Location;
	}

	public static double[] GenerateTrailVector_Best2(int UserID, int MaxID, double[][] P, int Best_UserID) {
		double SFGSS = 1;
		double SFHC = 0;
		double Fl = 0.1;
		double Fu = 0.9;
		double tuo1 = 0.1;
		double tuo2 = 0.03;
		double tuo3 = 0.07;
		double CR = 0.75;// 交叉的概率
		double[] temp = new double[featureDimension];
		double[] temp1 = new double[featureDimension];
		double[] temp2 = new double[featureDimension];
		double[] P_mutation = new double[featureDimension];
		double[] temp_P_trial = new double[featureDimension];
		double[] P_trial = new double[featureDimension];

		int u1 = UserID;
		int u2 = UserID;
		int u3 = UserID;
		int u4 = UserID;
		while ((u1 == UserID) || (u1 == Best_UserID)) {
			u1 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u2 == UserID) || (u2 == u1) || (u1 == Best_UserID)) {
			u2 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u3 == UserID) || (u3 == u2) || (u3 == u1) || (u1 == Best_UserID)) {
			u3 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u4 == UserID) || (u4 == u3) || (u4 == u2) || (u4 == u1) || (u4 == Best_UserID)) {
			u4 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}

		double rand1 = Math.random();
		double rand2 = Math.random();
		double rand3 = Math.random();
		double F = Math.random();
		double K = Math.random();
		if (rand3 < tuo2) {
			F = SFGSS;
		} else if (tuo2 <= rand3 && rand3 < tuo3) {
			F = SFHC;
		} else if (rand2 < tuo1 && rand3 > tuo3) {
			F = Fl + Fu * rand1;
		}
		
		vectorSub(P[u1], P[u2], temp);
		vectorMutiply(temp, F, temp1);
		vectorSub(P[u3], P[u4], temp);
		vectorMutiply(temp, F, temp2);
		vectorAdd(temp1, temp2, temp);
		vectorAdd(P[Best_UserID], temp, P_mutation);	
		vectorMeanRound(P_mutation,P_mutation);
		
		double rand0 = Math.random();
		int rand_d = (int) Math.round(Math.random() * (featureDimension - 1)); // random int [0,featureDimension-1]}
		for (int d = 0; d < featureDimension; d++) {
			if ((rand0 < CR) || (d == rand_d)) {
				P_trial[d] = P_mutation[d];
			} else {
				P_trial[d] = P[UserID][d];
			}
		}
		
//		vectorAdd(P_mutation, P[UserID], temp);
//		vectorMutiply(temp, K, temp1);
//		vectorAdd(P[UserID], temp1, P_trial);
//		vectorMeanRound(P_trial,P_trial);
//		
		return P_trial;
	}
	
	public static double[] GenerateTrailVector_Rand2(int UserID, int MaxID, double[][] P) {
		double SFGSS = 1;
		double SFHC = 0;
		double Fl = 0.1;
		double Fu = 0.9;
		double tuo1 = 0.1;
		double tuo2 = 0.03;
		double tuo3 = 0.07;
		double CR = 0.65;// 交叉的概率
		double[] temp = new double[featureDimension];
		double[] temp1 = new double[featureDimension];
		double[] temp2 = new double[featureDimension];
		double[] P_mutation = new double[featureDimension];
		double[] temp_P_trial = new double[featureDimension];
		double[] P_trial = new double[featureDimension];

		int u1 = UserID;
		int u2 = UserID;
		int u3 = UserID;
		int u4 = UserID;
		int u5 = UserID;
		while ((u1 == UserID)) {
			u1 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u2 == UserID) || (u2 == u1)) {
			u2 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u3 == UserID) || (u3 == u2) || (u3 == u1) ) {
			u3 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u4 == UserID) || (u4 == u3) || (u4 == u2) || (u4 == u1) ) {
			u4 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}
		while ((u5 == UserID) || (u5 == u4) || (u5 == u3) || (u5 == u2) || (u5 == u1)) {
			u5 = (int) Math.round(Math.random() * (MaxID - 1) + 1);
		} // random int [1,maxID]}

		double rand1 = Math.random();
		double rand2 = Math.random();
		double rand3 = Math.random();
		double F = Math.random();
		double K = Math.random();
		if (rand3 < tuo2) {
			F = SFGSS;
		} else if (tuo2 <= rand3 && rand3 < tuo3) {
			F = SFHC;
		} else if (rand2 < tuo1 && rand3 > tuo3) {
			F = Fl + Fu * rand1;
		}
		
		vectorSub(P[u2], P[u3], temp);
		vectorMutiply(temp, F, temp1);
		vectorSub(P[u4], P[u5], temp);
		vectorMutiply(temp, F, temp2);
		vectorAdd(temp1, temp2, temp);
		vectorAdd(P[u1], temp, P_mutation);	
		vectorMeanRound(P_mutation,P_mutation);
		
		double rand0 = Math.random();
		int rand_d = (int) Math.round(Math.random() * (featureDimension - 1)); // random int [0,featureDimension-1]}
		for (int d = 0; d < featureDimension; d++) {
			if ((rand0 < CR) || (d == rand_d)) {
				P_trial[d] = P_mutation[d];
			} else {
				P_trial[d] = P[UserID][d];
			}
		}
		
//		vectorAdd(P_mutation, P[UserID], temp);
//		vectorMutiply(temp, K, temp1);
//		vectorAdd(P[UserID], temp1, P_trial);
//		vectorMeanRound(P_trial,P_trial);
//		
		return P_trial;
	}
	
	public int getMaxIndex(double[] arr) {
		if (arr == null || arr.length == 1) {
			return 0;// 如果数组为空 或者是长度为0 就返回null
		}
		int maxIndex = 1;// 假设第一个元素为最大值 那么下标设为1
		double[] arrnew = new double[2];// 设置一个长度为2的数组用作记录，第一个元素存储最大值，第二个元素存储下标
		for (int i = 1; i <= arr.length - 1 - 1; i++) {
			if (arr[maxIndex] < arr[i + 1]) {
				maxIndex = i + 1;
			}
		}
		arrnew[0] = arr[maxIndex];
		arrnew[1] = maxIndex;
		return maxIndex;
	}

	public double[][] get_Rank_metric(int K) {
		double[] ndcg = new double[K + 1];
		double[] hit = new double[K + 1];
		double[] mrr = new double[K + 1];
		double[][] result = new double[3][K + 1];

		int test_num = 0;
		int userID = 1;
		int[] user_Positive_item = new int[item_MaxID + 1];
		int[] user_Negative_item = new int[item_MaxID + 1];
		int user_Positive_item_num = 0;
		int user_Negative_item_num = 0;

		for (RTuple tempTestRating : testData) {
			if (tempTestRating.iUserID == userID) {
				if (tempTestRating.dRating > 3.5) {
					user_Positive_item_num = user_Positive_item_num + 1;
					user_Positive_item[user_Positive_item_num] = tempTestRating.iItemID;
				} else {
					user_Negative_item_num = user_Negative_item_num + 1;
					user_Negative_item[user_Negative_item_num] = tempTestRating.iItemID;
				}
			} else {
				int tempuserID = userID;
				// 用户user的item已经全部存储完毕，开始计算该用户的NDCG
				if ((user_Positive_item_num != 0) && (user_Negative_item_num != 0)) {
					double[][] ndcg_user = new double[K + 1][user_Positive_item_num + 1];
					double[][] hit_user = new double[K + 1][user_Positive_item_num + 1];
					double[][] mrr_user = new double[K + 1][user_Positive_item_num + 1];
					int rand_Positive_idx = 0;
					test_num++;

					for (int i = 1; i <= user_Positive_item_num; i++) {
						int Positive_item;
						double[] tiny_test = new double[100 + 1 + 1];
						Positive_item = user_Positive_item[i];
						if (user_Negative_item_num >= 100) {
							Random random = new Random();
							rand_Positive_idx = random.nextInt(100 + 1) + 1;
							tiny_test[rand_Positive_idx] = this.getLocPrediction(tempuserID, Positive_item);
							// 随机选择100个负向商品进行计算
							int[] Negative_list = randomArray(1, user_Negative_item_num, 100);
							for (int index = 1, neg_index = 0; index <= 100 + 1; index++) {
								if (index == rand_Positive_idx)
									continue;
								int Negative_item = user_Negative_item[Negative_list[neg_index]];
								tiny_test[index] = this.getLocPrediction(tempuserID, Negative_item);
								neg_index++;
							}

						} else {
							tiny_test = new double[user_Negative_item_num + 1 + 1];
							Random random = new Random();
							rand_Positive_idx = random.nextInt(user_Negative_item_num + 1) + 1;
							tiny_test[rand_Positive_idx] = this.getLocPrediction(tempuserID, Positive_item);
							// 选择全部负向商品进行计算
							int[] Negative_list = randomArray(1, user_Negative_item_num, user_Negative_item_num);
							for (int index = 1, neg_index = 0; index <= user_Negative_item_num + 1; index++) {
								if (index == rand_Positive_idx)
									continue;
								int Negative_item = user_Negative_item[Negative_list[neg_index]];
								tiny_test[index] = this.getLocPrediction(tempuserID, Negative_item);
								neg_index++;
							}
						}
						// 排序得出positive排名
						int[] rank_list = Arraysort(tiny_test);
						int rank_ui = getArrayIndex(rank_list, rand_Positive_idx);
						// System.out.print("rank_ui: " + rank_ui + "\n");
						for (int k = 1; k <= K; k++) {
							if (rank_ui <= k) {
								hit_user[k][i] = 1;
								ndcg_user[k][i] = 1.0 / log2(1 + rank_ui);
								mrr_user[k][i] = 1.0 / rank_ui;
							}
						}
					} // 保存完
					double temp_hit = 0;
					double temp_ndcg = 0;
					double temp_mrr = 0;
					for (int k = 1; k <= K; k++) {
						temp_hit = 0;
						temp_ndcg = 0;
						temp_mrr = 0;
						for (int i = 1; i <= user_Positive_item_num; i++) {
							temp_hit = temp_hit + hit_user[k][i];
							temp_ndcg = temp_ndcg + ndcg_user[k][i];
							temp_mrr = temp_mrr + mrr_user[k][i];
						}
						temp_hit /= user_Positive_item_num;
						temp_ndcg /= user_Positive_item_num;
						temp_mrr /= user_Positive_item_num;
						hit[k] = hit[k] + temp_hit;
						ndcg[k] = ndcg[k] + temp_ndcg;
						mrr[k] = mrr[k] + temp_mrr;
					}
				}

				userID = tempTestRating.iUserID;
				user_Positive_item = new int[item_MaxID + 1];
				user_Negative_item = new int[item_MaxID + 1];
				user_Positive_item_num = 0;
				user_Negative_item_num = 0;

				if (tempTestRating.dRating > 3) {
					user_Positive_item_num = user_Positive_item_num + 1;
					user_Positive_item[user_Positive_item_num] = tempTestRating.iItemID;
				} else {
					user_Negative_item_num = user_Negative_item_num + 1;
					user_Negative_item[user_Negative_item_num] = tempTestRating.iItemID;
				}
			}
		}
		// 最后一个用户user的item已经全部存储完毕，开始计算该用户的NDCG
		if ((user_Positive_item_num != 0) && (user_Negative_item_num != 0)) {
			double[][] ndcg_user = new double[K + 1][user_Positive_item_num + 1];
			double[][] hit_user = new double[K + 1][user_Positive_item_num + 1];
			double[][] mrr_user = new double[K + 1][user_Positive_item_num + 1];
			int rand_Positive_idx = 0;
			test_num++;

			for (int i = 1; i <= user_Positive_item_num; i++) {
				int Positive_item;
				double[] tiny_test = new double[100 + 1 + 1];
				Positive_item = user_Positive_item[i];
				if (user_Negative_item_num >= 100) {
					Random random = new Random();
					rand_Positive_idx = random.nextInt(100 + 1) + 1;
					tiny_test[rand_Positive_idx] = this.getLocPrediction(userID, Positive_item);
					// 随机选择100个负向商品进行计算

					int[] Negative_list = randomArray(1, user_Negative_item_num, 100);
					for (int index = 1, neg_index = 0; index <= 100 + 1; index++) {
						if (index == rand_Positive_idx)
							continue;
						int Negative_item = user_Negative_item[Negative_list[neg_index]];
						tiny_test[index] = this.getLocPrediction(userID, Negative_item);
						neg_index++;
					}

				} else {
					tiny_test = new double[user_Negative_item_num + 1 + 1];
					Random random = new Random();
					rand_Positive_idx = random.nextInt(user_Negative_item_num + 1) + 1;
					tiny_test[rand_Positive_idx] = this.getLocPrediction(userID, Positive_item);
					// 选择全部负向商品进行计算
					int[] Negative_list = randomArray(1, user_Negative_item_num, user_Negative_item_num);
					for (int index = 1, neg_index = 0; index <= user_Negative_item_num + 1; index++) {
						if (index == rand_Positive_idx)
							continue;
						int Negative_item = user_Negative_item[Negative_list[neg_index]];
						tiny_test[index] = this.getLocPrediction(userID, Negative_item);
						neg_index++;
					}
				}
				// 排序得出positive排名
				int[] rank_list = Arraysort(tiny_test);
				int rank_ui = getArrayIndex(rank_list, rand_Positive_idx);
				for (int k = 1; k <= K; k++) {
					if (rank_ui <= k) {
						hit_user[k][i] = 1;
						ndcg_user[k][i] = 1.0 / log2(1 + rank_ui);
						mrr_user[k][i] = 1.0 / rank_ui;
					}
				}
			} // 保存完
			double temp_hit = 0;
			double temp_ndcg = 0;
			double temp_mrr = 0;
			for (int k = 1; k <= K; k++) {
				temp_hit = 0;
				temp_ndcg = 0;
				temp_mrr = 0;
				for (int i = 1; i <= user_Positive_item_num; i++) {
					temp_hit = temp_hit + hit_user[k][i];
					temp_ndcg = temp_ndcg + ndcg_user[k][i];
					temp_mrr = temp_mrr + mrr_user[k][i];
				}
				temp_hit /= user_Positive_item_num;
				temp_ndcg /= user_Positive_item_num;
				temp_mrr /= user_Positive_item_num;
				hit[k] = hit[k] + temp_hit;
				ndcg[k] = ndcg[k] + temp_ndcg;
				mrr[k] = mrr[k] + temp_mrr;
			}
		}

		// 计算平均值
		for (int k = 1; k <= K; k++) {
			hit[k] = hit[k] / test_num;
			result[0][k] = hit[k];
			ndcg[k] = ndcg[k] / test_num;
			result[1][k] = ndcg[k];
			mrr[k] = mrr[k] / test_num;
			result[2][k] = mrr[k];
		}
		return result;

	}

	public double log2(double N) {
		return Math.log(N) / Math.log(2);// Math.log的底为e
	}

	public static int[] Arraysort(double[] arr) {
		// double[] arr = {0.8,0.5,0.8,0.2,0.8,0.8};[ ,1,2,3,4,5,6]
		double temp;
		int index;
		int k = arr.length; // 0~k
		int[] Index = new int[k];
		for (int i = 1; i <= k - 1; i++) {
			Index[i] = i;
		}

		for (int i = 1; i <= arr.length - 1; i++) {
			for (int j = 1; j <= arr.length - 1 - i; j++) {
				if (arr[j] < arr[j + 1]) {
					temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;

					index = Index[j];
					Index[j] = Index[j + 1];
					Index[j + 1] = index;
				}
			}
		}
		return Index;
	}

	public int getArrayIndex(int[] arr, int value) {

		int k = 0;
		for (int i = 1; i < arr.length; i++) {
			if (arr[i] == value) {
				k = i;
				break;
			}
		}
		return k;
	}

	/**
	 * 随机指定范围内N个不重复的数 在初始化的无重复待选数组中随机产生一个数放入结果中， 将待选数组被随机到的数，用待选数组(len-1)下标对应的数替换
	 * 然后从len-2里随机产生下一个随机数，如此类推
	 * 
	 * @param max 指定范围最大值
	 * @param min 指定范围最小值
	 * @param n   随机数个数
	 * @return int[] 随机数结果集
	 */
	public static int[] randomArray(int min, int max, int n) {
		int len = max - min + 1;
		if (max < min || n > len) {
			return null;
		}

		// 初始化给定范围的待选数组
		int[] source = new int[len];
		for (int i = min; i < min + len; i++) {
			source[i - min] = i;
		}

		int[] result = new int[n];
		Random rd = new Random();
		int index = 0;
		for (int i = 0; i < result.length; i++) {
			// 待选数组0到(len-2)随机一个下标
			index = Math.abs(rd.nextInt() % len--);
			// 将随机到的数放入结果集
			result[i] = source[index];
			// 将待选数组中被随机到的数，用待选数组(len-1)下标对应的数替换
			source[index] = source[len];
		}
		return result;
	}

	public static boolean addFile(String string, String path) {
		// 文件的续写
		FileWriter fw = null;
		try {
			fw = new FileWriter(path, true);
			// 写入换行
			fw.write("\r\n");
			fw.write(string);
			fw.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	//////////////////////// 鎵�鏈夌殑璁粌缁撴潫//////////////////////////////////
	public static void main(String[] argv) throws NumberFormatException, IOException {

		int TimesOfEvolution = 20; // times of evolution
		int TypeOfBias = 1;// controlling the type of Bias:1 is no Bias, 2 is Bias as 2009 year's Paper
		int TypeOfLoss = 2;// 1 is F_norm L1 loss, others is L2 loss
		int TpyeOfRegularization = 2;// controlling regularization:1 is L1; 2 is L2.

		// 1 Hetrec-ml 2 ciao 3 Epinion 4 Ml1M 5 Yelp 6 Ml25M
		CommonRecomm_NEW.dataset_name = "Hetrec-ML";
		String trainpath = "D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\train.txt";
		String testpath = "D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\test.txt";
		CommonRecomm_NEW.initializeRatings(trainpath, testpath, " ");
		String addpath = "D:\\Lishihui\\DDE-hash\\" + dataset_name + "\\new_data2_mutation_test"
				+ "_result.txt";
		String string;

		for (int mutate = 3; mutate <= 3; mutate ++)
		{
			for (int s = 4; s <= 4; s = s+1)
			{
				for (int t = 5; t <= 5; t++) // setting the t according to your task
				{
					for (int q = 2; q<=2; q++) {
						if(q==1) {
							CommonRecomm_NEW.flag_init = true;
						}
						else {
							CommonRecomm_NEW.flag_init = false;
						}
						
						double Fx = Math.pow(2, (s));// for adjusting featureDimension
						int Fxx = (int) Fx;// for adjusting featureDimension
						CommonRecomm_NEW.mutate_type = mutate;

						CommonRecomm_NEW.lambda = Math.pow(10, (0 - 3)); //Math.pow(10, (0 - t)); //Math.pow(10, (0 - t));// Math.pow(10, (0 - t)) {0.1, 0.01,0.001,0.0001,0.00001}
						CommonRecomm_NEW.trainingRound = 3000;
						CommonRecomm_NEW.delayCount = 20;
						CommonRecomm_NEW.featureDimension = Fxx;// 10*Fxx
						
//						if (t==1) {
//							TimesOfEvolution = 1;
//						}
//						else if (t==2) {
//							TimesOfEvolution = 5;
//						}
//						else if (t==3) {
//							TimesOfEvolution = 30;
//						}
//						else if (t==4) {
//							TimesOfEvolution = 100;
//						}
//						else{
//							TimesOfEvolution = 1000;
//						}
						TimesOfEvolution = 1 ; //1*t; //(Fxx-Fxx%10)/10 +20 {1,5,10,15,20}
					
						CommonRecomm_NEW.initiStaticArrays();
						CommonRecomm_NEW.initBiasSettings(true, true, 1, 1);
						min_Error = 1e10;
						min_Error1 = 1e10;
						max_ndcg = 0;
						max_mrr = 0;
						max_hit = 0;

						MF_New2 mf_New = new MF_New2(1); //
						long startTime = System.currentTimeMillis();
					
						System.out.println("dataset_name: "+ CommonRecomm_NEW.dataset_name + "\t" + "featureDimension: " + featureDimension );

						mf_New.m = TypeOfBias;// controlling the type of Bias:1 is no Bias, 2 is Bias as 2009 year's Paper
						mf_New.G = TimesOfEvolution;/// times of evolution
						mf_New.tpyeOfRegularization = TpyeOfRegularization;// controlling regularization:1 is L1; 2 is L2.
						mf_New.typeOfLoss = TypeOfLoss;
						mf_New.train();
						
						addFile("G = " + mf_New.G + "\t" + "Mutate_type =" + mutate + "\t" + "flag_init =" + CommonRecomm_NEW.flag_init 
								+ "\t" + "Round:" + mf_New.min_Round + "\n", addpath);

						long endTime = System.currentTimeMillis();
						double seconds = (endTime - startTime) / 1000F;

						System.out.println("dataset_name: "+ CommonRecomm_NEW.dataset_name + "\t" + "Round:" + mf_New.min_Round + "\t" + "RMSE:" + "\t" + min_Error + "\t" + "MAE:"
							+ "\t" + min_Error1);


						System.out.println("featureDimension: " + featureDimension + "\t" + "lambda: " + lambda + "\t"
							+ min_Error + "\t" + min_Error1 + "\t");

						System.out.println("lambda" + lambda + "\t" + "RMSE:" + min_Error + "\t" + "MAE:" + min_Error1 + "\t"
							+ "\t" + "NDCG:" + max_ndcg + "\t" + "MRR:" + max_mrr + "\t" + "HIT:" + max_hit + "\t \n");
						string = ("featureDimension: " + featureDimension + "\t" + "lambda" + lambda + "\t" + "RMSE:"
							+ min_Error + "\t" + "MAE:" + min_Error1 + "\t" + "NDCG:" + max_ndcg + "\t" + "MRR:" + max_mrr
							+ "\t" + "HIT:" + max_hit + "\t \n");
						addFile(string, addpath);
						
					}
					
			}
		}
	}
}
}
